<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>/vehicle-checklist-pdf</title>
</head>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
</style>

<body>
    <h1>Visit /vehicle-checklist-pdf</h1>
    <h1>Visit /black-stone</h1>
</body>

</html>